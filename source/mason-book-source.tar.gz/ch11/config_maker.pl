#!/usr/bin/perl -w

use strict;

use Cwd;
use File::Spec;
use HTML::Mason;
use User::pwent;

my $comp_root =
    File::Spec->rel2abs( File::Spec->catfile( cwd(), 'config' ) );

my $output;
my $interp =
    HTML::Mason::Interp->new( comp_root  => $comp_root,
                              out_method => \$output,
                            );

my $user = getpwuid($<);

$interp->exec( '/httpd.conf.mas', user => $user );

my $file =  File::Spec->catfile( $user->dir, 'etc', 'httpd.conf' );
open FILE, ">$file" or die "Cannot open $file: $!";
print FILE $output;
close FILE;
