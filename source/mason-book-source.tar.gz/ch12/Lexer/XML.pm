package HTML::Mason::Lexer::XML;
$VERSION = '0.01';

use strict;

use HTML::Mason::Exceptions( abbr => [ qw( param_error syntax_error error ) ] );
use HTML::Mason::Lexer;
use Params::Validate qw(:all);
use XML::SAX::Base;
use XML::SAX::ParserFactory;
use base qw(HTML::Mason::Lexer XML::SAX::Base);  # Lexer comes first

__PACKAGE__->valid_params
  (
   xml_namespace => { parse => 'string', type => SCALAR, default => 'mason',
                      descr => "Prefix of XML tags indicating Mason sections" },
  );

sub lex {
    my ($self, %p) = @_;

    local $self->{name} = $p{name};
    local $self->{compiler} = $p{compiler};

    $self->{state} = [];

    my $parser = XML::SAX::ParserFactory->parser( Handler => $self );

    $parser->parse_string( $p{comp_source} );
}

sub start_element {
    my $self = shift;
    my $elt  = shift;

    if ( ! defined $elt->{Prefix} ||
         $elt->{Prefix} ne $self->{xml_namespace} ) {
        $self->_verbatim_start_element($elt);
        return;
    }

    if ( $elt->{LocalName} eq 'component' ) {
        $self->{compiler}->start_component;
    }

    foreach my $block ( qw( init perl args ) ) {
        if ( $elt->{LocalName} eq $block ) {
            $self->_start_block($block);
            last;
        }
    }

    if ( $elt->{LocalName} eq 'output' ) {
        $self->_start_output;
    }

    if ( $elt->{LocalName} eq 'arg' ) {
        $self->_handle_argument($elt);
    }
}

sub _verbatim_start_element {
    my $self = shift;
    my $elt  = shift;
    my $xml = '<' . $elt->{Name};

    my @att;
    foreach my $att ( values %{ $elt->{Attributes} } ) {
        push @att, qq|$att->{Name}="$att->{Value}"|;
    }

    if (@att) {
        $xml .= ' ';
        $xml .= join ' ', @att;
    }

    $xml .= '>';

    $self->{compiler}->text( text => $xml );
}

sub _start_block {
    my $self  = shift;
    my $block = shift;

    if ( $self->{state}[-1] &&
         $self->{state}[-1] ne 'def' &&
         $self->{state}[-1] ne 'method' ) {
        syntax_error "Cannot nest a $block tag inside a $self->{state}[-1] tag";
    }

    $self->{compiler}->start_block( block_type => $block );

    push @{ $self->{state} }, $block;
}

sub _start_output {
    my $self = shift;

    if ( $self->{state}[-1] &&
         $self->{state}[-1] ne 'def' &&
         $self->{state}[-1] ne 'method' ) {
        syntax_error "Cannot nest an output tag inside a $self->{state}[-1] tag";
    }

    push @{ $self->{state} }, 'output';
}

sub _handle_argument {
    my $self = shift;
    my $elt  = shift;

    my $var = $elt->{Attributes}{'{}name'}{Value};
    my $default = $elt->{Attributes}{'{}default'}{Value};

   unless ( $var =~ /^[\$\@%][^\W\d]\w*/ ) {
       syntax_error "Invalid variable name: $var";
   }

   $self->{compiler}->variable_declaration( block_type => 'args',
                                            type => substr( $var, 0, 1 ),
                                            name => substr( $var, 1 ),
                                            default => $default );
}

sub characters {
    my $self  = shift;
    my $chars = shift;

    if ( ! $self->{state}[-1] ||
         $self->{state}[-1] eq 'def' ||
         $self->{state}[-1] eq 'method' ) {
        $self->{compiler}->text( text => $chars->{Data} );
        return;
    }

    if ( $self->{state}[-1] eq 'init' ||
         $self->{state}[-1] eq 'perl' ) {
        $self->{compiler}->raw_block( block_type => $self->{state}[-1],
                                      block => $chars->{Data} );
        return;
    }

   if ( $self->{state}[-1] eq 'output' ) {
       $self->{compiler}->substitution( substitution => $chars->{Data} );
   }
}

sub ignorable_whitespace { $_[0]->characters( $_[1]->{Data} ) }

sub end_element {
    my $self = shift;
    my $elt  = shift;

    if ( ! defined $elt->{Prefix} ||
         $elt->{Prefix} ne $self->{xml_namespace} ) {
        $self->_verbatim_end_element($elt);
        return;
    }

    if ( $elt->{LocalName} eq 'component' ) {
        $self->{compiler}->end_component;
        return;
    }

    return if $elt->{LocalName} eq 'arg';

    if ( $self->{state}[-1] ne $elt->{LocalName} ) {
        syntax_error "Something very weird happened.  " .
                     "We encountered an ending tag for a $elt->{LocalName} tag " .
                     "before ending our current tag ($self->{state}[-1]).";
    }

    if ( $elt->{LocalName} eq 'output' ) {
        pop @{ $self->{state} };
        return;
    }

    $self->{compiler}->end_block( block_type => $elt->{LocalName} );

    pop @{ $self->{state} };
}

sub _verbatim_end_element {
    my $self = shift;
    my $elt  = shift;

    $self->{compiler}->text( text => "</$elt->{Name}>" );
}

1;
