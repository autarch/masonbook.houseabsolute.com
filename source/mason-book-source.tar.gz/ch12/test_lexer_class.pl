#!/usr/bin/perl -w

use strict;

use lib '.';
use HTML::Mason;

# not the real package name but finds the file properly.
use Lexer::XML;

my $interp =
    HTML::Mason::Interp->new
        ( lexer_class => 'HTML::Mason::Lexer::XML' );

my $xml = <<'EOF';
<?xml version="1.0"?>
<mason:component xmlns:mason="http://www.masonbook.com/">
 This is plain text.
 <b>This is text in an HTML tag</b>
 <mason:perl>
  my $x;
  if ($y &gt; 10) {
      $x = 10;
  } else {
      $x = 100;
  }
 </mason:perl>
 $x is <mason:output>$x</mason:output>
 $y is <mason:output>$y</mason:output>

 <mason:args>
  <mason:arg name="$y" />
  <mason:arg name="@z" default="(2,3)" />
 </mason:args>
 <mason:init>
  $y *= $_ foreach @z;
 </mason:init>
</mason:component>
EOF

my $comp = $interp->make_component( comp_source => $xml );

$interp->exec($comp, y => -1, z=>[5,-9]);

