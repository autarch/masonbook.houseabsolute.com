#!/usr/bin/perl -w

use strict;

use lib '.';
use HTML::Mason;

# not the real package name but finds the file properly.
use Resolver::MySQL;

# This test requires a MySQL database, obviously.
#
# To make the needed table, use this SQL:

=pod

 CREATE TABLE MasonComponent
 (
   path           VARCHAR(255)   PRIMARY KEY,
   component      TEXT           NOT NULL,
   last_modified  DATETIME       NOT NULL
 );

 INSERT INTO MasonComponent VALUES
  ( '/in_db',
    'I was found in the database: <% 2 + 2 %>',
    NOW()
  );

=cut

my $interp =
    HTML::Mason::Interp->new
        ( resolver_class => 'HTML::Mason::Resolver::MySQL',
	  db_name => 'masonbook_ch13',
	  user => 'root',
	);

my $comp = $interp->exec('/in_db');

