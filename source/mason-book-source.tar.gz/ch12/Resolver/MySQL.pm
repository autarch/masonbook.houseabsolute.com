package HTML::Mason::Resolver::MySQL;
$VERSION = '0.01';

use strict;

use DBI;
use Params::Validate qw(:all);

use HTML::Mason::ComponentSource;
use HTML::Mason::Resolver;
use base qw(HTML::Mason::Resolver);

__PACKAGE__->valid_params
    (
     db_name  => { parse => 'string', type => SCALAR },
     user     => { parse => 'string', type => SCALAR, optional => 1 },
     password => { parse => 'string', type => SCALAR, optional => 1 },
    );

sub new {
    my $class = shift;
    my $self = $class->SUPER::new(@_);

    $self->{dbh} =
        DBI->connect
            ( "dbi:mysql:$self->{db_name}",
              $self->{user}, $self->{password}, { RaiseError => 1 } );

    return $self;
}

sub get_info {
    my ($self, $path) = @_;

    my ($last_mod) =
        $self->{dbh}->selectrow_array
            ( 'SELECT UNIX_TIMESTAMP(last_modified) ' .
              'FROM MasonComponent WHERE path = ?',
              {}, $path );

    return unless $last_mod;

    return
        HTML::Mason::ComponentSource->new
            ( comp_path => $path,
              friendly_name => $path,
              last_modified => $last_mod,
              comp_id => $path,
              source_callback => sub { $self->_get_source($path) },
            );
}

sub _get_source {
    my $self = shift;
    my $path = shift;

    return 
        $self->{dbh}->selectrow_array
            ( 'SELECT component FROM MasonComponent WHERE path = ?', {}, $path );
}

sub glob_path {
    my $self = shift;
    my $pattern = shift;

    $pattern =~~ s/\*/%/g;

    return
        $self->{dbh}->selectcol_array
            ( 'SELECT path FROM MasonComponent WHERE path LIKE ?', {}, $pattern );
}

sub apache_request_to_comp_path {
    my $self = shift;
    my $r = shift;

    my $path = $r->uri;

    return $path
        if $self->{dbh}->selectrow_array
            ( 'SELECT 1 FROM MasonComponent WHERE path = ?', {}, $path );

    return undef unless $r->path_info;

    $path .= $r->path_info;
        
    return $path
        if $self->{dbh}->selectrow_array
            ( 'SELECT 1 FROM MasonComponent WHERE path = ?', {}, $path );

    return undef;
}

1;
