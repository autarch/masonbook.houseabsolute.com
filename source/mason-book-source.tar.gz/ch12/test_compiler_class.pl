#!/usr/bin/perl -w

use strict;

use lib '.';
use HTML::Mason;

# not the real package name but finds the file properly.
use Compiler::ToEmbperl;

my $compiler = HTML::Mason::Compiler::ToEmbperl->new;

my $source = <<'EOF';
<%once>my $once;</%once>
becomes "[! my $once; !]"

<% 1 %> becomes "[+ 1 +]"

% my $x = 1;
becomes "[*  my $x = 1; *]"

<%perl>my $y = 2;</%perl>
becomes "[* my $y = 2; *]"

<%init>1</%init> becomes "[* 1 *]" at top
EOF

print $compiler->compile( comp_source => $source );
