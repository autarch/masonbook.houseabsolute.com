package HTML::Mason::Request::WithSession;
$VERSION = '0.01';

use strict;

# Import a subroutine error() which throws an HTML::Mason::Exception
# object
use HTML::Mason::Exceptions ( abbr => [ 'error' ] );

use HTML::Mason::ApacheHandler;
use base qw(HTML::Mason::Request);

use Apache::Cookie;
use Cache::FileCache;
use Digest::SHA1;

sub new {
    my $class = shift;

    $class->alter_superclass( $HTML::Mason::ApacheHandler::VERSION ?
                              'HTML::Mason::Request::ApacheHandler' :
                              $HTML::Mason::CGIHandler::VERSION ?
                              'HTML::Mason::Request::CGI' :
                              'HTML::Mason::Request' );

    return $class->SUPER::new(@_);
}

sub exec {
    my $self = shift;

    $self->_make_session;

    my @result;
    if (wantarray) {
        @result = eval { $self->SUPER::exec(@_) };
    } elsif (defined wantarray) {
        $result[0] = eval { $self->SUPER::exec(@_) };
    } else {
        eval { $self->SUPER::exec(@_) };
    }

    # copy this in case _save_session overwrites $@
    my $e = $@;

    $self->_save_session;

    die $e if $e;

    return wantarray ? @result : defined wantarray ? $result[0] : undef;
}

sub _make_session {
    my $self = shift;

    if ( $self->is_subrequest ) {
        $self->{session} = $self->parent_request->session;
        return;
    }

    my %c = Apache::Cookie->fetch;
    my $session_id =
        exists $c{masonbook_session} ? $c{masonbook_session}->value : undef;

    $self->{session_cache} =
        Cache::FileCache->new( { cache_root => '/tmp',
                                 namespace  => 'Mason-Book-Session',
                                 default_expires_in  => 60 * 60 * 24, # 1 day
                                 auto_purge_interval => 60 * 60 * 24, # 1 day
                                 auto_purge_on_set => 1 } );

    my $session;
    if ($session_id) {
        $session = $self->{session_cache}->get($session_id);
    }

    unless ($session) {
        $session = { _session_id => Digest::SHA1::sha1_hex( time, rand, $$ ) };
    }

    Apache::Cookie->new( $self->apache_req,
                         name => 'masonbook_session',
                         value => $session->{_session_id},
                         path => '/',
                         expires => '+1d',
                       )->bake;

    $self->{session} = $session;
}

sub _save_session {
    my $self = shift;

    $self->{session_cache}->set
        ( $self->{session}{_session_id} => $self->{session} );
}

sub session { $_[0]->{session} }

1;
