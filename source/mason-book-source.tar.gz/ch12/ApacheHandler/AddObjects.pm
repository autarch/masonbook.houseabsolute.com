package HTML::Mason::ApacheHandler::AddObjects;
$VERSION = '0.01';

use strict;

use HTML::Mason::ApacheHandler;
use base qw(HTML::Mason::ApacheHandler);

use Date::ICal;  # date object
use MyApp::User; # user object

sub request_args {
    my $self = shift;

    my ($args, $r, $cgi_object) = $self->SUPER::request_args(@_);

    if ( exists $args->{epoch} ) {
        $args->{date} = Date::ICal->new( epoch => $args->{epoch} );
    }

    if ( exists $args->{user_id} ) {
        $args->{user} = MyApp::User->new( user_id => $args->{user_id} );
    }

    return ($args, $r, $cgi_object);
}

1;
