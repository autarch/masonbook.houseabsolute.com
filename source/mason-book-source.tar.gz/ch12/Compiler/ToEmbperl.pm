package HTML::Mason::Compiler::ToEmbperl;
$VERSION = '0.01';

use strict;

use HTML::Mason::Lexer;
use HTML::Mason::Exceptions ( abbr => [qw(syntax_error)] );
use HTML::Mason::Compiler;
use base qw(HTML::Mason::Compiler);

sub compile {
    my ($self, %p) = @_;

    $self->lexer->lex( comp_source => $p{comp_source},
                       name => 'Embperl',
                       compiler => $self );

    return $self->component_as_embperl;
}

sub start_component {
    my $self = shift;

    $self->{once_header} = '';
    $self->{header} = '';
    $self->{body}   = '';
    $self->{footer} = '';

    $self->{current_block} = '';
}

sub start_block {
    my ($self, %p) = @_;

    syntax_error "Cannot nest a $p{block_type} inside a $self->{in_block} block"
        if $self->{in_block};

    $self->{in_block} = $p{block_type};
}

sub raw_block {
    my ($self, %p) = @_;

    for ($self->{in_block}) {
        /^once$/     and   $self->{once_header} .= $p{block};
        /^init$/     and   $self->{header}      .= $p{block};
        /^perl$/     and   $self->{body}        .= "[* $p{block} *]";
        /^cleanup$/  and   $self->{footer}      .= $p{block};
    }
}

sub text_block {
    my ($self, %p) = @_;
    $self->{body} .= $p{block};
}

sub text {
    my ($self, %p) = @_;
    $self->{body} .= $p{text};
}

sub substitution {
    my ($self, %p) = @_;
    $self->{body} .= "[+ $p{substitution} +]";
}

sub perl_line {
    my ($self, %p) = @_;
    $self->{body} .= "[* $p{line} *]";
}

sub end_block {
    my ($self, %p) = @_;

    syntax_error "end of $p{block_type} encountered while in $self->{in_block} block"
        unless $self->{in_block} eq $p{block_type};

    $self->{in_block} = undef;
}

sub component_as_embperl {
    my $self = shift;

    my $page = '';

    if ( length $self->{once_header} ) {
        $page .= "[! $self->{once_header} !]\n";
    }

    if ( length $self->{header} ) {
        $page .= "[* $self->{header} *]\n";
    }

    if ( length $self->{body} ) {
        $page .= "$self->{body}\n";
    }

    if ( length $self->{footer} ) {
        $page .= "[* $self->{footer} *]\n";
    }

    return $page;
}

1;
