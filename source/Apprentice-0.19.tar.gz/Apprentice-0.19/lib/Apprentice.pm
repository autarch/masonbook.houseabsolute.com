package Apprentice;

use strict;

use vars qw($VERSION);

$VERSION = '0.19';

use Apache::Constants;
use Apache::Cookie;
use Apache::Request;
use Apprentice::Data;
use Digest::SHA1;
use Email::Valid;
use HTML::FromText ();
use MIME::Lite;
use Time::Piece;
use URI;
use URI::Escape ();

{
    package HTML::Mason::Commands;

    use Alzabo::SQLMaker::MySQL qw( NOW );
}

$Apprentice::Secret = '!!SECRET!!';

sub send_email
{
    my %p = @_;

    my $msg = MIME::Lite->new( From    => $p{from},
			       To      => $p{to},
			       Subject => $p{subject},
			       Data    => $p{body},
			     );

    $msg->send;
}


1;

__END__

=head1 NAME

Apprentice - Perl Apprentice site

=head1 SYNOPSIS

  PerlModule  Apprentice

=head1 DESCRIPTION

This module loads the various modules needed for the Perl Apprentice
web site.

=head1 USAGE

Besides loading other modules, this module provides two important
features for the Apprentice site.  The first is the global variable
C<$Apprentice::SECRET>, which is used to create hashes for cookies.

The second is the C<send_mail> subroutine.  This method accepts the
parameters "from", "to", "subject", and "body".  Given these
parameters, it will create and send a mail message.

=cut
