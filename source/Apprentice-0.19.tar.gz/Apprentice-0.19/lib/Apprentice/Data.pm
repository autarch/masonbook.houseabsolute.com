package Apprentice::Data;

use strict;

use Exception::Class ( 'Apprentice::Exception::DataValidation' =>
		       { fields => [ 'errors' ] },
		     );

use Lingua::EN::Inflect ();

sub namer
{
    my %p = @_;

    return $p{table}->name . '_t' if $p{type} eq 'table';

    return $p{column}->name . '_c' if $p{type} eq 'table_column';

    return $p{column}->name if $p{type} eq 'row_column';

    if ( $p{type} eq 'foreign_key' )
    {
	my $name = $p{foreign_key}->table_to->name;
	my $from = $p{foreign_key}->table_from->name;
	$name =~ s/$from//;

	if ($p{plural})
	{
	    return my_PL( $name );
	}
	else
	{
	    return $name;
	}
    }

    if ( $p{type} eq 'linking_table' )
    {
	my $method = $p{foreign_key}->table_to->name;
	my $tname = $p{foreign_key}->table_from->name;
	$method =~ s/$tname//;

	return my_PL($method);
    }

    return $p{column}->name if $p{type} eq 'lookup_columns';

    return $p{parent} ? 'parent' : 'children'
	if $p{type} eq 'self_relation';

    die "unknown type in call to naming sub: $p{type}\n";
}

sub my_PL
{
    my $name = shift;

    return 'Categories' if $name eq 'Category';

    return Lingua::EN::Inflect::PL($name);
}

my $Schema;
sub schema
{
    return $Schema if $Schema;

    $Schema = Alzabo::Runtime::Schema->load_from_file( name => !!DB_NAME!! );
    $Schema->connect( user => !!DB_USER!!,
		      password => !!DB_PASSWORD!!,
		      host => !!DB_HOST!!,
		    );

    $Schema->set_referential_integrity(1);

    return $Schema;
}

package Apprentice::Data::Table::Project;

sub pre_insert
{
    my $self = shift;
    my $p = shift;

    $self->validate_data( $p->{values}, 1 );
}

sub validate_data
{
    my $self = shift;
    my $data = shift;
    my $insert = shift;

    my @errors;

    foreach my $field ( qw( name description ) )
    {
	push @errors,
	    "The \u$field field is required."
		unless defined $data->{$field} && length $data->{$field};
    }

    push @errors, "Difficulty must be between one and ten."
	unless $data->{difficulty} >= 1 && $data->{difficulty} <= 10;

    Apprentice::Exception::DataValidation->throw( errors => \@errors ) if @errors;
}

package Apprentice::Data::Row::Project;

sub pre_update
{
    my $self = shift;

    $self->table->validate_data(shift);
}

sub user_is_admin
{
    my $self = shift;
    my $user = shift;

    return
	$Schema->function
	    ( select => $Schema->ProjectMember_t->user_id_c,
	      tables => $Schema->ProjectMember_t,
	      where => [ [ $Schema->ProjectMember_t->project_id_c, '=', $self->project_id ],
			 [ $Schema->ProjectMember_t->user_id_c, '=', $user->user_id ],
			 [ $Schema->ProjectMember_t->is_project_admin_c, '=', 1 ] ] );
}

package Apprentice::Data::Row::Category;

sub project_count
{
    my $self = shift;

    return $Schema->ProjectCategory_t->row_count
	       ( where =>
		 [ $Schema->ProjectCategory_t->category_id_c, '=', $self->category_id ] );
}

package Apprentice::Data::Table::User;

use Email::Valid;

sub pre_insert
{
    my $self = shift;
    my $p = shift;

    $self->validate_data( $p->{values}, 1 );
}

sub validate_data
{
    my $self = shift;
    my $data = shift;
    my $insert = shift;

    my @errors;

    foreach ( ( map { [ $_ => $self->column($_)->length ] }
		qw( username password real_name email_address ) ),
	      [ password2 => 100 ],
	    )
    {
	my ($field, $max) = @$_;
	(my $nice_name = $field) =~ tr/_/ /;

	push @errors,
	    "The $nice_name field is required."
		unless defined $data->{$field} && length $data->{$field};

	push @errors, "The $nice_name field cannot be longer than $max characters."
	    if defined $data->{$field} && length $data->{$field} > $max;
    }

    if ( ( ( defined $data->{username} && length $data->{username} && $insert ) ||
	   ( exists $data->{old_username} && $data->{old_username} ne $data->{username} ) ) &&
	 $self->one_row
	     ( where => [ $self->username_c, '=', $data->{username} ] )
       )
    {
	push @errors, "This username already exists in the system.";
    }

    if ( defined $data->{password} && defined $data->{password2} &&
	 $data->{password} ne $data->{password2} )
    {
	push @errors, "The two password fields are not identical.";
    }

    if ( defined $data->{password} && defined $data->{password2} &&
	 length $data->{password} && length $data->{password} < 6 )
    {
	push @errors, "Your password must be at least six characters long.";
    }

    if ( defined $data->{email_address} && length $data->{email_address} &&
	 ! Email::Valid->address( $data->{email_address} ) )
    {
	push @errors, "The email address you gave is not valid.";
    }

    Apprentice::Exception::DataValidation->throw( errors => \@errors ) if @errors;

    delete $data->{password2};
}

package Apprentice::Data::Row::User;

sub pre_update
{
    my $self = shift;
    my $data = shift;

    $data->{old_username} = $self->username;

    $self->table->validate_data($data);

    delete $data->{old_username};
}

sub is_logged_in { 1 }

sub has_projects
{
    my $self = shift;

    return
	$Schema->ProjectMember_t->row_count
	    ( where => [ [ $Schema->ProjectMember_t->user_id_c, '=', $self->user_id ],
			 [ $Schema->ProjectMember_t->is_project_admin_c, '=', 1 ] ] );
}

sub is_project_admin
{
    my $self = shift;
    my $project = shift;

    return
	$Schema->function
	    ( select => $Schema->ProjectMember_t->user_id_c,
	      tables => $Schema->ProjectMember_t,
	      where => [ [ $Schema->ProjectMember_t->user_id_c, '=', $self->user_id ],
			 [ $Schema->ProjectMember_t->project_id_c, '=', $project->project_id ],
			 [ $Schema->ProjectMember_t->is_project_admin_c, '=', 1 ] ] );
}

package Apprentice::Data::PotentialRow::User;

sub is_logged_in { 0 }

package Apprentice::Data;

# Do this at the end so all the subroutines are already defined.
use Alzabo::MethodMaker ( schema => !!DB_NAME!!,
			  all => 1,
			  class_root => 'Apprentice::Data',
			  name_maker => \&namer,
			);

1;
