#!/usr/bin/perl

use strict;
use warnings;

use lib '/home/autarch/book/site/lib';

use Apprentice::Data;
use Alzabo::SQLMaker::MySQL qw(NOW);

my $schema = Apprentice::Data->schema;

my @user_ids;
foreach my $x (1..40)
{
    my $user = $schema->User_t->insert( values => { username => "Dummy user $x",
						    password => 'dummy01',
						    real_name => "Bubba $x",
						    email_address => "bubba$x\@urth.org",
						    user_status_id => random(1, 3),
						    is_admin => 0,
						  } );

    push @user_ids, $user->user_id;
}

foreach my $x (1..150)
{
    my $proj = $schema->Project_t->insert( values => { name => "Dummy project $x",
						       description => "A dummy project for testing: $x",
						       creation_date => NOW(),
						       difficulty => random(1, 10),
						       project_status_id => random(1, 2),
						       project_support_level_id => random(1, 3),
						     } );

    $schema->ProjectCategory_t->insert( values => { project_id => $proj->project_id,
						    category_id => random(1, 7) } );

    $schema->ProjectMember_t->insert( values => { project_id => $proj->project_id,
						  user_id => $user_ids[ random(0, $#user_ids) ],
						  role_id => random(1,2),
						  is_project_admin => 1 } );

    foreach ( 0..random(0, 3) )
    {
	# just ignore inserts of duplicate values
	eval
	{
	    $schema->ProjectMember_t->insert( values => { project_id => $proj->project_id,
							  user_id => $user_ids[ random(0, $#user_ids) ], } );
	};
    }
}

sub random
{
    my ($min, $max) = @_;

    return int( rand($max - $min) + $min );
}
